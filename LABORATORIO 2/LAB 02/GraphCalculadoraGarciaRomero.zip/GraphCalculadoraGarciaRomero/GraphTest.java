import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * La clase GraphTest contiene pruebas unitarias para la clase Graph y GraphCalculator.
 * Estas pruebas verifican el comportamiento esperado de los métodos de ambas clases,
 * incluyendo la creación de grafos, la manipulación de aristas, la consulta de información
 * y la realización de operaciones sobre grafos.
 */
public class GraphTest {

    /**
     * Configura el entorno de prueba.
     * Este método se ejecuta antes de cada caso de prueba.
     */
    @Before
    public void setUp() {
        // Puede usarse para inicializar objetos o configuraciones necesarias para las pruebas.
    }

    /**
     * Limpia el entorno de prueba.
     * Este método se ejecuta después de cada caso de prueba.
     */
    @After
    public void tearDown() {
        // Puede usarse para liberar recursos o limpiar configuraciones después de las pruebas.
    }

    /**
     * Prueba que se pueda crear un grafo vacío.
     */
    @Test
    public void shouldCreateEmptyGraph() {
        String[] vertices = {};
        String[][] edges = {};
        assertEquals(0, new Graph(vertices, edges).vertices());
        assertEquals(0, new Graph(vertices, edges).edges());
    }

    /**
     * Prueba que se pueda crear un grafo con vértices y aristas.
     */
    @Test
    public void shouldCreateGraphs() {
        String[] vertices = {"DDYA", "MYSD", "DOPO"};
        String[][] edges = {{"DDYA", "MYSD"}, {"DDYA", "DOPO"}};
        assertEquals(3, new Graph(vertices, edges).vertices());
        assertEquals(2, new Graph(vertices, edges).edges());
    }

    /**
     * Prueba que no se permitan vértices o aristas duplicados en el grafo.
     */
    @Test
    public void shouldNotHaveDuplicateVerticesEdges() {
        String[] vertices = {"DDYA", "MYSD", "DOPO", "DOPO"};
        String[][] edges = {{"DDYA", "MYSD"}, {"DDYA", "DOPO"}, {"DDYA", "DOPO"}};
        assertEquals(3, new Graph(vertices, edges).vertices());
        assertEquals(2, new Graph(vertices, edges).edges());
    }

    /**
     * Prueba que el grafo no sea sensible a mayúsculas y minúsculas.
     */
    @Test
    public void shouldNotBeCaseSensitive() {
        String[] vertices = {"Ddya", "MYSD", "DOPO", "dopo"};
        String[][] edges = {{"DDYA", "Mysd"}, {"ddya", "dopo"}, {"DDya", "doPo"}};
        assertEquals(3, new Graph(vertices, edges).vertices());
        assertEquals(2, new Graph(vertices, edges).edges());
    }

    /**
     * Prueba que el método toString devuelva la representación correcta del grafo.
     */
    @Test
    public void shouldConvertToString() {
        String[] vertices = {"DDYA", "MYSD", "DOPO"};
        String[][] edges = {{"DDYA", "MYSD"}, {"DDYA", "DOPO"}};
        String data = "(DDYA, DOPO) (DDYA, MYSD)";
        assertEquals(data, new Graph(vertices, edges).toString());
    }

    /**
     * Prueba que dos grafos sean iguales si tienen los mismos vértices y aristas.
     */
    @Test
    public void shouldValidateEquality() {
        String[] vertices = {};
        String[][] edges = {};
        assertEquals(new Graph(vertices, edges), new Graph(vertices, edges));

        String[] verticesA = {"DDYA", "MYSD", "DOPO"};
        String[][] edgesA = {{"DDYA", "MYSD"}, {"DDYA", "DOPO"}};
        String[] verticesB = {"Ddya", "MYSD", "DOPO", "dopo"};
        String[][] edgesB = {{"DDYA", "Mysd"}, {"ddya", "dopo"}, {"DDya", "doPo"}};
        assertEquals(new Graph(verticesA, edgesA), new Graph(verticesB, edgesB));
    }
    
    //MINICILO 1
    /**
     * Prueba que se pueda asignar un grafo a una variable en la calculadora.
     */
    @Test
    public void shouldAssignGraphToVariable() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices, edges);
        assertNotNull(calculator.consult("g1"));
    }

    /**
     * Prueba que no se pueda asignar un grafo a una variable con nombre nulo.
     */
    @Test
    public void shouldNotAssignGraphWithNullName() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        calculator.assign(null, vertices, edges);
        assertNull(calculator.consult(null));
    }

    /**
     * Prueba que se devuelva la información correcta del grafo al consultar una variable.
     */
    @Test
    public void shouldReturnCorrectGraphInfo() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices, edges);

        String result = calculator.consult("g1");
        assertEquals("Vértices: 3, Aristas: 2, Grafo: (A, B) (B, C)", result);
    }

    /**
     * Prueba que no se devuelva información para una variable que no existe.
     */
    @Test
    public void shouldNotReturnInfoForNonExistentVariable() {
        GraphCalculator calculator = new GraphCalculator();
        String result = calculator.consult("g1"); // Intenta consultar una variable que no existe
        assertNull(result);
    }
    
    //MINICILO 2
    /**
     * Prueba que se pueda eliminar una arista existente en el grafo.
     */
    @Test
    public void shouldDeleteEdge() {
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        Graph graph = new Graph(vertices, edges);

        graph.removeEdge("A", "B");
        assertFalse(graph.toString().contains("(A, B)"));
    }

    /**
     * Prueba que no se pueda eliminar una arista que no existe en el grafo.
     */
    @Test
    public void shouldNotDeleteNonExistentEdge() {
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}};
        Graph graph = new Graph(vertices, edges);

        graph.removeEdge("B", "C");
        assertFalse(graph.toString().contains("(B, C)"));
    }

    /**
     * Prueba que se pueda eliminar una arista independientemente del orden de los vértices.
     */
    @Test
    public void shouldDeleteEdgeRegardlessOfOrder() {
        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        Graph graph = new Graph(vertices, edges);

        graph.removeEdge("B", "A");
        assertFalse(graph.toString().contains("(A, B)"));
    }

    //MINICILO 3
    
    /**
     * Prueba que se pueda realizar la unión de dos grafos.
     */
    @Test
    public void shouldPerformUnion() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices1 = {"A", "B", "C"};
        String[][] edges1 = {{"A", "B"}};
        calculator.assign("g1", vertices1, edges1);

        String[] vertices2 = {"B", "C", "D"};
        String[][] edges2 = {{"B", "C"}};
        calculator.assign("g2", vertices2, edges2);

        calculator.assignBinary("g3", "g1", 'u', "g2");
        String result = calculator.consult("g3");
        assertTrue(result.contains("(A, B)") && result.contains("(B, C)"));
    }

    /**
     * Prueba que se pueda realizar la intersección de dos grafos.
     */
    @Test
    public void shouldPerformIntersection() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices1 = {"A", "B", "C"};
        String[][] edges1 = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices1, edges1);

        String[] vertices2 = {"B", "C", "D"};
        String[][] edges2 = {{"B", "C"}};
        calculator.assign("g2", vertices2, edges2);

        calculator.assignBinary("g3", "g1", 'i', "g2");
        String result = calculator.consult("g3");
        assertTrue(result.contains("(B, C)"));
        assertFalse(result.contains("(A, B)"));
    }

    /**
     * Prueba que se pueda realizar la diferencia de dos grafos.
     */
    @Test
    public void shouldPerformDifference() {
        GraphCalculator calculator = new GraphCalculator();

        // Crear el primer grafo (g1)
        String[] vertices1 = {"A", "B", "C" , "D"};
        String[][] edges1 = {{"A", "B"}, {"B", "C"}, {"C","D"}};
        calculator.assign("g1", vertices1, edges1);

        // Crear el segundo grafo (g2)
        String[] vertices2 = {"C", "D"};
        String[][] edges2 = {{"C", "D"}};
        calculator.assign("g2", vertices2, edges2);

        // Realizar la operación de diferencia: g3 = g1 - g2
        calculator.assignBinary("g3", "g1", 'd', "g2");

        // Consultar el resultado de g3
        String result = calculator.consult("g3");

        // Verificar que el resultado contiene la arista (A, B)
        assertTrue("El resultado debería contener la arista [(A, B)]", result.contains("(A, B)"));

        // Verificar que el resultado no contiene la arista (B, C)
        assertFalse("El resultado no debería contener la arista (B, C)", result.contains("(B, C)"));

        // Verificar que el resultado no contiene el vértice D
        assertFalse("El resultado no debería contener el vértice D", result.contains("D"));
    }

    /**
     * Prueba que se pueda realizar la junta de dos grafos.
     */
    @Test
    public void shouldPerformJoin() {
        GraphCalculator calculator = new GraphCalculator();
        String[] vertices1 = {"A", "B"};
        String[][] edges1 = {{"A", "B"}};
        calculator.assign("g1", vertices1, edges1);

        String[] vertices2 = {"C", "D"};
        String[][] edges2 = {{"C", "D"}};
        calculator.assign("g2", vertices2, edges2);

        calculator.assignBinary("g3", "g1", 'j', "g2");
        String result = calculator.consult("g3");
        assertTrue(result.contains("(A, C)") && result.contains("(A, D)") &&
                   result.contains("(B, C)") && result.contains("(B, D)"));
    }

    //BONO
    /**
     * Prueba que devuelve el grafo más grande al comparar dos grafos.
     */
    @Test
    public void shouldReturnLargerGraph() {
        GraphCalculator calculator = new GraphCalculator();

        String[] vertices1 = {"A", "B", "C"};
        String[][] edges1 = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices1, edges1);

        String[] vertices2 = {"D", "E", "F"};
        String[][] edges2 = {{"D", "E"}};
        calculator.assign("g2", vertices2, edges2);

        assertEquals("g1", calculator.compareGraphs("g1", "g2"));
    }

    /**
     * Prueba que se devuelva "Iguales" al comparar dos grafos con el mismo número de aristas.
     */
    @Test
    public void shouldReturnEqualGraphs() {
        GraphCalculator calculator = new GraphCalculator();

        String[] vertices1 = {"A", "B", "C"};
        String[][] edges1 = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices1, edges1);

        String[] vertices2 = {"D", "E", "F"};
        String[][] edges2 = {{"D", "E"}, {"E", "F"}};
        calculator.assign("g2", vertices2, edges2);

        assertEquals("Iguales", calculator.compareGraphs("g1", "g2"));
    }

    /**
     * Prueba que un grafo sea conexo.
     */
    @Test
    public void shouldBeConnected() {
        GraphCalculator calculator = new GraphCalculator();

        String[] vertices = {"A", "B", "C"};
        String[][] edges = {{"A", "B"}, {"B", "C"}};
        calculator.assign("g1", vertices, edges);

        assertTrue(calculator.isConnected("g1"));
    }

    /**
     * Prueba que un grafo no sea conexo.
     */
    @Test
    public void shouldNotBeConnected() {
        GraphCalculator calculator = new GraphCalculator();

        String[] vertices = {"A", "B", "C", "D"};
        String[][] edges = {{"A", "B"}, {"C", "D"}};
        calculator.assign("g1", vertices, edges);

        assertFalse(calculator.isConnected("g1"));
    }

    //PRUEBAS INTENCIONALES
    /**
     * Prueba de investigación de laboratorio que falla intencionalmente.
     */
    @Test
    public void failTest() {
        assertEquals(10, 5 + 4); // Esta prueba fallará porque 5 + 4 no es igual a 10.
    }

    /**
     * Prueba de investigación de laboratorio que pasa correctamente.
     */
    @Test
    public void passTest() {
        assertEquals(10, 5 + 5); // Esta prueba pasará porque 5 + 5 es igual a 10.
    }

    /**
     * Prueba de investigación de laboratorio que genera un error intencional.
     */
    @Test
    public void errorTest() {
        int[] array = {1, 2, 3};
        int valor = array[5]; // Esta prueba generará un error porque el índice 5 está fuera de los límites del arreglo.
    }
}