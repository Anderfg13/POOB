import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;
import java.util.*;

/**
 * La clase Graph representa un grafo no dirigido con vértices y aristas.
 * Los vértices se almacenan como un conjunto de cadenas, y las aristas se almacenan
 * como un conjunto de cadenas en formato "(A, B)", donde A y B son vértices.
 * 
 * Esta clase proporciona métodos para agregar y eliminar aristas, verificar la existencia
 * de vértices, encontrar caminos entre vértices, realizar operaciones de unión entre grafos,
 * y obtener representaciones en cadena del grafo.
 */
public class Graph {
    private Set<String> vertices; // Conjunto de vértices del grafo
    private Set<String> edges;    // Conjunto de aristas del grafo

    /**
     * Constructor de la clase Graph.
     *
     * @param vertices Un arreglo de cadenas que representa los vértices del grafo.
     * @param edges    Un arreglo bidimensional de cadenas que representa las aristas del grafo.
     *                 Cada arista debe ser un arreglo de dos elementos (vértice1, vértice2).
     */
    public Graph(String[] vertices, String[][] edges) {
        this.vertices = new TreeSet<>();
        this.edges = new TreeSet<>();

        // Agregar vértices al grafo
        for (String vertex : vertices) {
            this.vertices.add(vertex.toUpperCase());
        }

        // Agregar aristas al grafo
        for (String[] edge : edges) {
            addEdge(edge[0], edge[1]);
        }
    }

    /**
     * Agrega una arista entre dos vértices en el grafo.
     *
     * @param verticeUno El primer vértice de la arista.
     * @param verticeDos El segundo vértice de la arista.
     */
    public void addEdge(String verticeUno, String verticeDos) {
        String u = verticeUno.toUpperCase();
        String v = verticeDos.toUpperCase();

        // Formatear la arista como (A, B) donde A < B alfabéticamente
        String edge = u.compareTo(v) < 0 ? String.format("(%s, %s)", u, v) : String.format("(%s, %s)", v, u);

        // Agregar la arista solo si ambos vértices existen
        if (vertices.contains(u) && vertices.contains(v)) {
            edges.add(edge);
        }
    }

    /**
     * Elimina una arista entre dos vértices en el grafo.
     *
     * @param verticeUno El primer vértice de la arista.
     * @param verticeDos El segundo vértice de la arista.
     */
    public void removeEdge(String verticeUno, String verticeDos) {
        // Convertir los vértices a mayúsculas
        String u = verticeUno.toUpperCase();
        String v = verticeDos.toUpperCase();

        // Formatear la arista como (A, B) donde A < B alfabéticamente
        String edge = u.compareTo(v) < 0 ? String.format("(%s, %s)", u, v) : String.format("(%s, %s)", v, u);

        // Eliminar la arista si existe
        if (edges.contains(edge)) {
            edges.remove(edge);
            System.out.println("Arco eliminado entre " + u + " y " + v);
        } else {
            System.out.println("No existe un arco entre " + u + " y " + v);
        }
    }

    /**
     * Verifica si un vértice existe en el grafo.
     *
     * @param vertex El vértice a verificar.
     * @return `true` si el vértice existe en el grafo, `false` en caso contrario.
     */
    public boolean contains(String vertex) {
        return vertices.contains(vertex.toUpperCase());
    }

       /**
     * Realiza la unión de este grafo con otro grafo.
     *
     * @param other El grafo con el que se realizará la unión.
     * @return Un nuevo grafo que representa la unión de ambos grafos.
     */
    public Graph union(Graph other) {
        Set<String> newVertices = new TreeSet<>(this.vertices);
        newVertices.addAll(other.vertices);

        Set<String> newEdges = new TreeSet<>(this.edges);
        newEdges.addAll(other.edges);

        return new Graph(newVertices.toArray(new String[0]), parseEdges(newEdges));
    }

    /**
     * Realiza la intersección de este grafo con otro grafo.
     *
     * @param other El grafo con el que se realizará la intersección.
     * @return Un nuevo grafo que contiene solo los vértices y aristas comunes a ambos grafos.
     */
    public Graph intersection(Graph other) {
        Set<String> newVertices = new TreeSet<>(this.vertices);
        newVertices.retainAll(other.vertices);

        Set<String> newEdges = new TreeSet<>(this.edges);
        newEdges.retainAll(other.edges);

        return new Graph(newVertices.toArray(new String[0]), parseEdges(newEdges));
    }

    /**
     * Realiza la diferencia de este grafo con otro grafo.
     *
     * @param other El grafo con el que se realizará la diferencia.
     * @return Un nuevo grafo que contiene los vértices y aristas del primer grafo que no están en el segundo grafo.
     */
    public Graph difference(Graph other) {
    // 1. Calcular la diferencia de vértices
    Set<String> newVertices = new TreeSet<>(this.vertices);
    newVertices.removeAll(other.vertices);

    // 2. Calcular la diferencia de aristas
    Set<String> newEdges = new TreeSet<>();
    for (String edge : this.edges) {
        // Extraer los vértices de la arista en formato "(v1, v2)"
        String[] vertices = edge.replace("(", "").replace(")", "").split(", ");
        if (vertices.length != 2) {
            throw new IllegalArgumentException("La arista '" + edge + "' no está en el formato correcto (v1, v2).");
        }

        String v1 = vertices[0];
        String v2 = vertices[1];

        // Solo agregar la arista si ambos vértices están en newVertices
        if (newVertices.contains(v1) || newVertices.contains(v2)) {
            newEdges.add(edge);
        }
    }
    System.out.println("Vértices de g3: " + newVertices);
    System.out.println("Aristas de g3: " + newEdges);   
    // 3. Crear un nuevo grafo con los vértices y aristas resultantes
    return new Graph(newVertices.toArray(new String[0]), parseEdges(newEdges));
}

    /**
     * Realiza la junta de este grafo con otro grafo.
     *
     * @param other El grafo con el que se realizará la junta.
     * @return Un nuevo grafo que combina ambos grafos y añade aristas entre todos los vértices del primer grafo y todos los vértices del segundo grafo.
     */
    public Graph join(Graph other) {
        Set<String> newVertices = new TreeSet<>(this.vertices);
        newVertices.addAll(other.vertices);

        Set<String> newEdges = new TreeSet<>(this.edges);
        newEdges.addAll(other.edges);

        // Añadir aristas entre todos los vértices del primer grafo y todos los vértices del segundo grafo
        for (String vertex1 : this.vertices) {
            for (String vertex2 : other.vertices) {
                String edge = vertex1.compareTo(vertex2) < 0 ? String.format("(%s, %s)", vertex1, vertex2) : String.format("(%s, %s)", vertex2, vertex1);
                newEdges.add(edge);
            }
        }

        return new Graph(newVertices.toArray(new String[0]), parseEdges(newEdges));
    }
    
    /**
     * Encuentra un camino entre dos vértices en el grafo.
     *
     * @param start El vértice de inicio del camino.
     * @param end   El vértice de destino del camino.
     * @return Una cadena que representa el camino entre los vértices en formato "(A, B) (B, C)".
     *         Si no hay camino, devuelve `null`.
     */
    public String path(String start, String end) {
        // Convertir los vértices a mayúsculas
        start = start.toUpperCase();
        end = end.toUpperCase();

        // Verificar si los vértices existen en el grafo
        if (!vertices.contains(start) || !vertices.contains(end)) {
            return null;
        }

        // Inicializar estructuras para DFS
        Set<String> visited = new TreeSet<>();
        Map<String, String> parent = new TreeMap<>(); // Para reconstruir el camino
        Stack<String> stack = new Stack<>();

        // Iniciar DFS desde el vértice de inicio
        stack.push(start);
        visited.add(start);

        boolean pathFound = false;

        while (!stack.isEmpty()) {
            String current = stack.pop();

            // Si llegamos al vértice de destino, reconstruir el camino
            if (current.equals(end)) {
                pathFound = true;
                break;
            }

            // Explorar los vértices adyacentes
            for (String edge : edges) {
                String[] verticesInEdge = edge.replace("(", "").replace(")", "").split(", ");
                String u = verticesInEdge[0];
                String v = verticesInEdge[1];

                if (u.equals(current) && !visited.contains(v)) {
                    stack.push(v);
                    visited.add(v);
                    parent.put(v, current); // Registrar el padre para reconstruir el camino
                } else if (v.equals(current) && !visited.contains(u)) {
                    stack.push(u);
                    visited.add(u);
                    parent.put(u, current); // Registrar el padre para reconstruir el camino
                }
            }
        }

        // Si no se encontró un camino, devolver null
        if (!pathFound) {
            return null;
        }

        // Reconstruir el camino desde end hasta start
        List<String> path = new ArrayList<>();
        String current = end;
        while (current != null) {
            path.add(current);
            current = parent.get(current);
        }
        Collections.reverse(path); // Invertir para obtener el orden correcto

        // Crear un nuevo grafo que represente el camino
        String[] pathVertices = path.toArray(new String[0]);
        String[][] pathEdges = new String[path.size() - 1][2];

        for (int i = 0; i < path.size() - 1; i++) {
            pathEdges[i][0] = path.get(i);
            pathEdges[i][1] = path.get(i + 1);
        }

        String newGraph = (new Graph(pathVertices, pathEdges)).toString();
        return newGraph;
    }
    
    //BONO
    /**
     * Obtiene el conjunto de vértices del grafo.
     */
    public Set<String> getVertices() {
        return vertices;
    }
    
    /**
     * Obtiene el conjunto de aristas del grafo.
     */
    public Set<String> getEdges() {
        return edges;
    }

    

    /**
     * Devuelve la cantidad de vértices en el grafo.
     *
     * @return El número de vértices en el grafo.
     */
    public int vertices() {
        return vertices.size();
    }

    /**
     * Devuelve la cantidad de aristas en el grafo.
     *
     * @return El número de aristas en el grafo.
     */
    public int edges() {
        return edges.size();
    }

    /**
     * Compara este grafo con otro objeto para verificar si son iguales.
     *
     * @param obj El objeto a comparar.
     * @return `true` si los grafos son iguales, `false` en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Graph)) return false;
        Graph other = (Graph) obj;
        return this.vertices.equals(other.vertices) && this.edges.equals(other.edges);
    }

    /**
     * Devuelve una representación en cadena del grafo.
     *
     * @return Una cadena que representa las aristas del grafo en formato ordenado.
     */
    @Override
    public String toString() {
        List<String> sortedEdges = new ArrayList<>(edges);
        Collections.sort(sortedEdges);
        return String.join(" ", sortedEdges);
    }

    /**
     * Convierte un conjunto de aristas en formato String a un arreglo bidimensional de String.
     *
     * @param edgeSet El conjunto de aristas en formato "(A, B)".
     * @return Un arreglo bidimensional de String que representa las aristas.
     */
    private String[][] parseEdges(Set<String> edgeSet) {
        List<String[]> edgeList = new ArrayList<>();
        for (String edge : edgeSet) {
            String[] parts = edge.replace("(", "").replace(")", "").split(", ");
            edgeList.add(parts);
        }
        return edgeList.toArray(new String[0][]);
    }
}