import java.util.TreeMap;
import java.util.Set;
import java.util.TreeSet;

/** GraphCalculator.java
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 */
/**
 * La clase GraphCalculator representa una calculadora de grafos que permite almacenar
 * y manipular múltiples grafos mediante variables.
 * 
 * Esta clase proporciona métodos para crear variables, asignar grafos a variables,
 * realizar operaciones unarias y binarias sobre grafos, y consultar la información
 * de los grafos almacenados.
 */
public class GraphCalculator{

    private TreeMap<String, Graph> variables;
    private boolean ok;
    
    /**
     * Constructor de la clase GraphCalculator.
     * Inicializa una nueva calculadora de grafos con un mapa vacío de variables.
     */
    //MINICICLO 1
    public GraphCalculator() {
        variables = new TreeMap<>();
    }

    // Asigna un grafo a una variable
        /**
     * Asigna un grafo a una variable en la calculadora.
     *
     * Este método crea un nuevo grafo a partir de los vértices y aristas proporcionados,
     * y lo asocia a la variable especificada. Si la variable ya existe, se sobrescribe.
     *
     * @param nombre   El nombre de la variable a la que se asignará el grafo.
     *                No debe ser nulo.
     * @param vertices Un arreglo de cadenas que representa los vértices del grafo.
     *                No debe ser nulo.
     * @param edges    Un arreglo bidimensional de cadenas que representa las aristas del grafo.
     *                Cada arista debe ser un arreglo de dos elementos (vértice1, vértice2).
     *                No debe ser nulo.
     *
     */
    public void assign(String nombre, String[] vertices, String[][] edges) {
        if (nombre == null || vertices == null || edges == null) {
            ok(null);
            return;
        } else {
            ok("bien");
            Graph graph = new Graph(vertices, edges);
            variables.put(nombre, graph);
        }
    }
    
    // Consulta un grafo por su nombre
        /**
     * Consulta la información de un grafo almacenado en la calculadora.
     *
     * Este método devuelve una cadena que contiene la cantidad de vértices, la cantidad de aristas
     * y la representación en cadena del grafo asociado a la variable especificada.
     *
     * @param nombre El nombre de la variable que contiene el grafo a consultar.
     * @return Una cadena con el formato "Vértices: X, Aristas: Y, Grafo: Z", donde:
     *         - X es la cantidad de vértices en el grafo.
     *         - Y es la cantidad de aristas en el grafo.
     *         - Z es la representación en cadena del grafo (aristas en formato ordenado).
     *         Si la variable no existe o es nula, devuelve `null`.
     */
    public String consult(String nombre) {
        if (nombre == null) {
            ok(null);
            return null;
        }
    
        if (!variables.containsKey(nombre)) {
            ok(null);
            return null;
        }
    
        Graph graph = variables.get(nombre);
        if (graph == null) {
            ok(null);
            return null;
        }
    
        int vertexCount = graph.vertices();
        int edgeCount = graph.edges();
        String graphString = graph.toString();
        
        ok("bien");
        return String.format("Vértices: %d, Aristas: %d, Grafo: %s", vertexCount, edgeCount, graphString);
    }
    
    //MINICICLO 2

     /**
     * Realiza operaciones unarias sobre un grafo almacenado, utilizando dos vértices y un operador.
     * Las operaciones incluyen insertar una arista, eliminar una arista, verificar la pertenencia de vértices
     * y encontrar un camino entre dos vértices.
     *
     * @param graphName Nombre del grafo sobre el cual se realizará la operación. Debe ser una clave existente en el mapa de variables.
     * @param vertexA   Primer vértice proporcionado por el usuario. Se utiliza para realizar operaciones como agregar/eliminar aristas o verificar su existencia.
     * @param vertexB   Segundo vértice proporcionado por el usuario. Se utiliza junto con {@code vertexA} para realizar operaciones.
     * @param op        Operador que indica la operación a realizar. Los valores válidos son:
     *                      '+' Insertar una arista entre los vertices
     *                      '-' Eliminar una arista entre los vertices.</li>
     *                      '?' Verificar si los vertices pertenecen al grafo.
     *                      'p': Encontrar un camino entre los vertices
     */
    public void assignUnary(String graphName, String vertexA, String vertexB, char op) {
        // Verificar si la variable 'graphName' existe
        if (!variables.containsKey(graphName)) {
            System.out.println("La variable '" + graphName + "' no existe.");
            ok(null);
            return;
        }
    
        // Obtener el grafo asociado a la variable 'graphName'
        Graph graph = variables.get(graphName);
    
        switch (op) {
            case '+':
                // Insertar arco entre los vértices 'vertexA' y 'vertexB'
                if (graph.contains(vertexA) && graph.contains(vertexB)) {
                    graph.addEdge(vertexA, vertexB);
                    ok("bien");
                    System.out.println("Arco agregado entre " + vertexA + " y " + vertexB);
                } else {
                    ok(null);
                    System.out.println("Uno o ambos vértices no existen en el grafo.");
                }
                break;
    
            case '-':
                // Eliminar arco entre los vértices 'vertexA' y 'vertexB'
                if (graph.contains(vertexA) && graph.contains(vertexB)) {
                    graph.removeEdge(vertexA, vertexB);
                    ok("bien");
                    System.out.println("Arco eliminado entre " + vertexA + " y " + vertexB);
                } else {
                    ok(null);
                    System.out.println("Uno o ambos vértices no existen en el grafo.");
                }
                break;
    
            case '?':
                // Verificar si ambos vértices 'vertexA' y 'vertexB' pertenecen al grafo
                boolean vertexAExists = graph.contains(vertexA);
                boolean vertexBExists = graph.contains(vertexB);
    
                if (vertexAExists && vertexBExists) {
                    ok("bien");
                    System.out.println("Ambos vértices '" + vertexA + "' y '" + vertexB + "' pertenecen al grafo.");
                } else {
                    ok(null);
                    System.out.println("Uno o ambos vértices no pertenecen al grafo.");
                }
                break;
    
            case 'p':
                // Encontrar un camino entre los vértices 'vertexA' y 'vertexB'
                if (graph.contains(vertexA) && graph.contains(vertexB)) {
                    String path = graph.path(vertexA, vertexB);
                    if (path != null) {
                        ok("bien");
                        System.out.println("Camino encontrado: " + path);
                    } else {
                        ok(null);
                        System.out.println("No se encontró un camino entre " + vertexA + " y " + vertexB);
                    }
                } else {
                    ok(null);
                    System.out.println("Uno o ambos vértices no existen en el grafo.");
                }
                break;
    
            default:
                ok(null);
                System.out.println("Operador no válido: " + op);
                break;
        }
    }
    
    /**
     * Realiza una operación binaria sobre dos grafos y asigna el resultado a una variable.
     *
     * @param a   Nombre de la variable donde se creara el nuevo grafo.
     * @param b   Nombre del primer grafo a realizar operación.
     * @param op  Operador que indica la operación a realizar: 'u' (unión), 'i' (intersección),
     *            'd' (diferencia), 'j' (junta).
     * @param c   Nombre del segundo grafo a realizar operación.
     */
    public void assignBinary(String a, String b, char op, String c) {
        // Verificar si las variables 'b' y 'c' existen
        if (!variables.containsKey(b) || !variables.containsKey(c)) {
            System.out.println("Una o ambas variables no existen.");
            ok(null);
            return;
        }
    
        // Obtener los grafos asociados a las variables 'b' y 'c'
        Graph graph1 = variables.get(b);
        Graph graph2 = variables.get(c);
    
        Graph resultGraph = null;
    
        switch (op) {
            case 'u':
                // Unión de los grafos
                resultGraph = graph1.union(graph2);
                ok("bien");
                break;
    
            case 'i':
                // Intersección de los grafos
                resultGraph = graph1.intersection(graph2);
                ok("bien");
                break;
    
            case 'd':
                // Diferencia de los grafos
                resultGraph = graph1.difference(graph2);
                ok("bien");
                break;
    
            case 'j':
                // Junta de los grafos
                resultGraph = graph1.join(graph2);
                ok("bien");
                break;
    
            default:
                System.out.println("Operador no válido: " + op);
                ok(null);
                return;
        }
    
        // Asignar el grafo resultante a la variable 'a'
        variables.put(a, resultGraph);
        ok("bien");
        System.out.println("Operación '" + op + "' realizada y asignada a la variable '" + a + "'.");
    }
    
    //BONO
    /**
     * Verifica si un grafo es conexo, esto quiere decir que todos los vertices tienen un arco entre todos.
     *
     * @param graphName Nombre del grafo a verificar.
     * @return `true` si el grafo es conexo, `false` en caso contrario.
     */
    public boolean isConnected(String graphName) {
        if (!variables.containsKey(graphName)) {
            System.out.println("La variable '" + graphName + "' no existe.");
            ok(null);
            return false;
        }
    
        Graph graph = variables.get(graphName);
    
        // Si el grafo no tiene vértices, se considera conexo
        if (graph.vertices() == 0) {
            ok("bien");
            return true;
        }
    
        // Obtener el primer vértice del grafo
        String startVertex = graph.getVertices().iterator().next();
    
        // Realizar un DFS desde el primer vértice
        Set<String> visited = new TreeSet<>();
        dfs(graph, startVertex, visited);
    
        // Si todos los vértices fueron visitados, el grafo es conexo
        ok("bien");
        return visited.size() == graph.vertices();
    }

    /**
     * Realiza un recorrido DFS (Depth-First Search) en el grafo.
     *
     * @param graph    El grafo en el que se realizará el DFS.
     * @param vertex   El vértice actual.
     * @param visited  Conjunto de vértices visitados.
     */
    private void dfs(Graph graph, String vertex, Set<String> visited) {
        visited.add(vertex);
    
        // Explorar los vértices adyacentes
        for (String edge : graph.getEdges()) {
            String[] verticesInEdge = edge.replace("(", "").replace(")", "").split(", ");
            String u = verticesInEdge[0];
            String v = verticesInEdge[1];
    
            if (u.equals(vertex) && !visited.contains(v)) {
                dfs(graph, v, visited);
            } else if (v.equals(vertex) && !visited.contains(u)) {
                dfs(graph, u, visited);
            }
        }
    }
    
    /**
     * Compara dos grafos por la cantidad de aristas que poseen.
     *
     * @param graphName1 Nombre del primer grafo a comparar.
     * @param graphName2 Nombre del segundo grafo a comparar.
     */
    public String compareGraphs(String graphName1, String graphName2) {
        if (!variables.containsKey(graphName1)) {
            ok(null);
            throw new IllegalArgumentException("El grafo '" + graphName1 + "' no existe.");
        }
        if (!variables.containsKey(graphName2)) {
            ok(null);
            throw new IllegalArgumentException("El grafo '" + graphName2 + "' no existe.");
        }
    
        Graph graph1 = variables.get(graphName1);
        Graph graph2 = variables.get(graphName2);
    
        int edges1 = graph1.edges();
        int edges2 = graph2.edges();
    
        if (edges1 > edges2) {
            return graphName1;
        } else if (edges2 > edges1) {
            return graphName2;
        } else {
            ok("bien");
            return "Iguales";
        }
    }

    /**
     * Establece el estado de la última operación.
     * Si el valor es null, se considera que la operación fue exitosa.
     * En caso contrario, se considera que la operación falló.
     *
     * @param valor El valor que indica el resultado de la operación.
     */
    private void ok(String valor) {
        if (valor == null) {
            this.ok = false;
        } else {
            this.ok = true;
        }
    }

    /**
     * Devuelve el estado de la última operación.
     *
     * @return true si la última operación fue exitosa, false en caso contrario.
     */
    public boolean isOk() {
        return this.ok;
    }
}
    



