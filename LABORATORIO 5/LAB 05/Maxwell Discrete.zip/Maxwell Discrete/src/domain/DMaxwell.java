package domain;

import java.awt.Color;
import java.util.List;

/**
 * Clase que representa la lógica del Demonio de Maxwell discreto.
 * Maneja el movimiento de partículas y la validación de posiciones en el tablero.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class DMaxwell {
    private final int rows;
    private final int cols;
    private final List<Particle> particles;
    private final List<Hole> holes;

    /**
     * Constante que representa la dirección hacia arriba.
     */
    public static final int UP = 0;
    
    /**
     * Constante que representa la dirección hacia abajo.
     */
    public static final int DOWN = 1;
    
    /**
     * Constante que representa la dirección hacia la izquierda.
     */
    public static final int LEFT = 2;
    
    /**
     * Constante que representa la dirección hacia la derecha.
     */
    public static final int RIGHT = 3;

    /**
     * Constructor que inicializa el tablero con sus dimensiones y elementos.
     *
     * @param rows Número de filas del tablero
     * @param cols Número de columnas del tablero
     * @param particles Lista de partículas en el tablero
     * @param holes Lista de hoyos en el tablero
     */
    public DMaxwell(int rows, int cols, List<Particle> particles, List<Hole> holes) {
        this.rows = rows;
        this.cols = cols;
        this.particles = particles;
        this.holes = holes;
    }

    /**
     * Verifica si una posición dada corresponde a una pared.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición es una pared, false en caso contrario
     */
    private boolean isWall(int row, int col) {
        // Paredes exteriores
        if (col == 0 || col == cols - 1 || row == 0 || row == rows - 1) {
            return true;
        }

        // Pared vertical en el centro con un espacio en el medio
        int middleCol = cols / 2;
        int middleRow = rows / 2;
        if (col == middleCol && row != middleRow) {
            return true;
        }

        return false;
    }

    /**
     * Determina si un movimiento a una posición específica es válido.
     *
     * @param row Fila destino
     * @param col Columna destino
     * @return true si el movimiento es válido, false en caso contrario
     */
    public boolean isValidMove(int row, int col) {
        return row >= 0 && row < rows &&
               col >= 0 && col < cols &&
               !isWall(row, col) &&
               !isParticleOccupied(row, col);
    }

    /**
     * Verifica si una posición está ocupada por una partícula.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición está ocupada por una partícula, false en caso contrario
     */
    private boolean isParticleOccupied(int row, int col) {
        for (Particle particle : particles) {
            if (particle.getRow() == row && particle.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    /**
     * Mueve una partícula en la dirección especificada si el movimiento es válido.
     *
     * @param particle Partícula a mover
     * @param direction Dirección del movimiento (UP, DOWN, LEFT, RIGHT)
     */
    public void moveParticle(Particle particle, int direction) {
        int newRow = particle.getRow();
        int newCol = particle.getCol();

        switch (direction) {
            case UP:
                newRow--;
                break;
            case DOWN:
                newRow++;
                break;
            case LEFT:
                newCol--;
                break;
            case RIGHT:
                newCol++;
                break;
        }

        if (isValidMove(newRow, newCol)) {
            particle.move(newRow, newCol);
        }
    }

    /**
     * Verifica si una posición dada contiene un hoyo.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición contiene un hoyo, false en caso contrario
     */
    public boolean isHole(int row, int col) {
        for (Hole hole : holes) {
            if (hole.getRow() == row && hole.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    /**
     * Calcula el porcentaje de partículas bien ubicadas en el tablero.
     * Las partículas rojas deben estar en la izquierda y las azules en la derecha.
     *
     * @return Porcentaje de partículas correctamente posicionadas (0.0 a 100.0)
     */
    public double infoContainer() {
        if (particles.isEmpty()) {
            return 0.0;
        }

        int correctlyPositioned = 0;
        for (Particle particle : particles) {
            if (particle.getColor().equals(Color.RED) && particle.getCol() < cols / 2) {
                correctlyPositioned++;
            } else if (particle.getColor().equals(Color.BLUE) && particle.getCol() >= cols / 2) {
                correctlyPositioned++;
            }
        }

        return (double) correctlyPositioned / particles.size() * 100;
    }

    /**
     * Calcula el porcentaje de partículas que han caído en hoyos.
     * Asume un número inicial fijo de 20 partículas.
     *
     * @return Porcentaje de partículas perdidas en hoyos (0.0 a 100.0)
     */
    public double getLostInHolesPercentage() {
        int totalExpectedParticles = 20;
        int missingParticles = totalExpectedParticles - particles.size();

        if (missingParticles < 0) {
            missingParticles = 0;
        }

        return (double) missingParticles / totalExpectedParticles * 100;
    }
}