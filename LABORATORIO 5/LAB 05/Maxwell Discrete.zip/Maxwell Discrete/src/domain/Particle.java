package domain;

import java.awt.Color;

/**
 * Representa una partícula en el juego del Demonio de Maxwell.
 * Las partículas pueden moverse por el tablero y tienen un color específico.
 * Implementa la interfaz MovableEntity para permitir su movimiento controlado.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class Particle extends Square implements MovableEntity {
    private int row;
    private int col;

    /**
     * Constructor que crea una partícula con color y posición específicos.
     *
     * @param color Color de la partícula
     * @param row Fila inicial de la partícula
     * @param col Columna inicial de la partícula
     */
    public Particle(Color color, int row, int col) {
        super(color);
        this.row = row;
        this.col = col;
    }

    /**
     * Mueve la partícula a una nueva posición.
     *
     * @param row Nueva fila para la partícula
     * @param col Nueva columna para la partícula
     */
    @Override
    public void move(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * Obtiene la fila actual de la partícula.
     *
     * @return Fila actual de la partícula
     */
    @Override
    public int getRow() {
        return row;
    }

    /**
     * Obtiene la columna actual de la partícula.
     *
     * @return Columna actual de la partícula
     */
    @Override
    public int getCol() {
        return col;
    }

    /**
     * Establece la fila de la partícula.
     *
     * @param row Nueva fila para la partícula
     */
    public void setRow(int row) {
        this.row = row;
    }

    /**
     * Establece la columna de la partícula.
     *
     * @param col Nueva columna para la partícula
     */
    public void setCol(int col) {
        this.col = col;
    }

    /**
     * Verifica si la partícula puede moverse a una posición específica.
     * Nota: La lógica real de validación se maneja en la clase DMaxwell.
     *
     * @param row Fila destino a verificar
     * @param col Columna destino a verificar
     * @return Siempre devuelve true, la validación real se delega a DMaxwell
     */
    @Override
    public boolean canMoveTo(int row, int col) {
        return true; // La lógica específica se maneja en DMaxwell
    }
}
