package domain;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import javax.swing.JPanel;

/**
 * Representa una casilla cuadrada en el tablero del Demonio de Maxwell.
 * Cada casilla puede tener un color específico y se ajusta dinámicamente al tamaño del tablero.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class Square extends JPanel {
    private Color color;
    private int rows;
    private int cols;

    /**
     * Constructor que crea una casilla con el color especificado.
     *
     * @param color Color inicial de la casilla
     */
    public Square(Color color) {
        this.color = color;
        setBackground(color);
    }

    /**
     * Establece el número de filas para el cálculo del tamaño preferido.
     *
     * @param rows Número de filas
     */
    public void setRows(int rows) {
        this.rows = rows;
    }

    /**
     * Establece el número de columnas para el cálculo del tamaño preferido.
     *
     * @param cols Número de columnas
     */
    public void setCols(int cols) {
        this.cols = cols;
    }

    /**
     * Calcula el tamaño preferido de la casilla basado en las dimensiones del contenedor padre.
     * El tamaño se ajusta para mantener una cuadrícula uniforme en el tablero.
     *
     * @return Dimensiones preferidas para esta casilla
     */
    @Override
    public Dimension getPreferredSize() {
        // Obtener el tamaño del padre y ajustar según sea necesario
        Container parent = getParent();
        if (parent != null && rows > 0 && cols > 0) {
            int size = Math.min(parent.getWidth() / cols, parent.getHeight() / rows);
            return new Dimension(size, size);
        }
        return super.getPreferredSize();
    }

    /**
     * Obtiene el color actual de la casilla.
     *
     * @return Color de la casilla
     */
    public Color getColor() {
        return color;
    }

    /**
     * Establece un nuevo color para la casilla y actualiza su apariencia.
     *
     * @param color Nuevo color para la casilla
     */
    public void setColor(Color color) {
        this.color = color;
        setBackground(color);
    }
}


