package domain;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Controlador principal del juego que maneja la lógica del Demonio de Maxwell.
 * Coordina el movimiento de partículas, la creación de elementos y el estado del juego.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class GameController {
    private final DMaxwell maxwell;
    private final List<Particle> particles;
    private final List<Hole> holes;
    private boolean isRunning;
    private final Random random;
    private final int rows;
    private final int cols;

    /**
     * Constructor que inicializa el controlador del juego con las dimensiones especificadas.
     *
     * @param rows Número de filas del tablero
     * @param cols Número de columnas del tablero
     */
    public GameController(int rows, int cols) {
        this.particles = new ArrayList<>();
        this.holes = new ArrayList<>();
        this.maxwell = new DMaxwell(rows, cols, particles, holes);
        this.isRunning = false;
        this.random = new Random();
        this.rows = rows;
        this.cols = cols;
    }

    /**
     * Alterna el estado de ejecución del juego (iniciar/detener).
     */
    public void toggleGame() {
        isRunning = !isRunning;
    }

    /**
     * Verifica si el juego está en ejecución.
     *
     * @return true si el juego está en ejecución, false en caso contrario
     */
    public boolean isRunning() {
        return isRunning;
    }

    /**
     * Mueve todas las partículas en la dirección especificada.
     *
     * @param direction Dirección del movimiento (DMaxwell.UP, DMaxwell.DOWN, etc.)
     * @throws IllegalStateException si el juego no está en ejecución
     */
    public void moveAllParticles(int direction) {
        if (!isRunning) {
            throw new IllegalStateException("El juego no está en ejecución");
        }

        List<Particle> particlesToRemove = new ArrayList<>();
        for (Particle particle : new ArrayList<>(particles)) {
            maxwell.moveParticle(particle, direction);
            if (isParticleInHole(particle)) {
                particlesToRemove.add(particle);
            }
        }
        particles.removeAll(particlesToRemove);
    }

    /**
     * Verifica si una partícula está dentro de un hoyo.
     *
     * @param particle Partícula a verificar
     * @return true si la partícula está en un hoyo, false en caso contrario
     */
    private boolean isParticleInHole(Particle particle) {
        return holes.stream()
                   .anyMatch(hole -> hole.getRow() == particle.getRow() && 
                                   hole.getCol() == particle.getCol());
    }

    /**
     * Obtiene el porcentaje de partículas bien ubicadas.
     *
     * @return Porcentaje de partículas correctamente posicionadas
     */
    public double infoContainer() {
        return maxwell.infoContainer();
    }

    /**
     * Obtiene el porcentaje de partículas perdidas en hoyos.
     *
     * @return Porcentaje de partículas atrapadas en hoyos
     */
    public double getLostInHolesPercentage() {
        return maxwell.getLostInHolesPercentage();
    }

    /**
     * Añade una partícula al juego.
     *
     * @param particle Partícula a añadir
     */
    public void addParticle(Particle particle) {
        particles.add(particle);
    }

    /**
     * Añade un hoyo al juego.
     *
     * @param hole Hoyos a añadir
     */
    public void addHole(Hole hole) {
        holes.add(hole);
    }

    /**
     * Obtiene la lista de partículas actuales.
     *
     * @return Lista de partículas
     */
    public List<Particle> getParticles() {
        return particles;
    }

    /**
     * Obtiene la lista de hoyos actuales.
     *
     * @return Lista de hoyos
     */
    public List<Hole> getHoles() {
        return holes;
    }

    /**
     * Añade una partícula con color específico en una posición aleatoria válida.
     *
     * @param color Color de la partícula a añadir
     */
    private void addParticle(Color color) {
        int row, col;
        do {
            row = random.nextInt(rows);
            col = random.nextInt(cols);
        } while (isWall(row, col) || isOccupied(row, col));

        Particle particle = new Particle(color, row, col);
        particles.add(particle);
        addParticle(particle);
    }

    /**
     * Añade un hoyo en una posición aleatoria válida.
     */
    private void addHole() {
        int row, col;
        do {
            row = random.nextInt(rows);
            col = random.nextInt(cols);
        } while (isWall(row, col) || isOccupied(row, col));

        Hole hole = new Hole(row, col);
        holes.add(hole);
        addHole(hole);
    }

    /**
     * Verifica si una posición es una pared (no implementado).
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return false (pendiente de implementación)
     */
    private boolean isWall(int row, int col) {
        // Placeholder for wall-checking logic
        return false;
    }

    /**
     * Verifica si una posición está ocupada (no implementado).
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return false (pendiente de implementación)
     */
    private boolean isOccupied(int row, int col) {
        // Placeholder for occupied-checking logic
        return false;
    }
}