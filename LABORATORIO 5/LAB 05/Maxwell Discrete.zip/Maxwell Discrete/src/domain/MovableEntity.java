package domain;

/**
 * Define el comportamiento de entidades movibles en el juego del Demonio de Maxwell.
 * Proporciona la funcionalidad básica para movimiento y verificación de posiciones.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public interface MovableEntity {
    /**
     * Mueve la entidad a una nueva posición especificada.
     *
     * @param row Fila destino para el movimiento
     * @param col Columna destino para el movimiento
     */
    void move(int row, int col);

    /**
     * Obtiene la posición actual de la entidad en filas.
     *
     * @return Número de fila donde se encuentra la entidad
     */
    int getRow();

    /**
     * Obtiene la posición actual de la entidad en columnas.
     *
     * @return Número de columna donde se encuentra la entidad
     */
    int getCol();

    /**
     * Verifica si la entidad puede moverse a la posición especificada.
     *
     * @param row Fila destino a verificar
     * @param col Columna destino a verificar
     * @return true si el movimiento es válido, false si la posición no está disponible
     */
    boolean canMoveTo(int row, int col);
}