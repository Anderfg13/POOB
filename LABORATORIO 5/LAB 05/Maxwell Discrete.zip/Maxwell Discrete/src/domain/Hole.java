package domain;

import java.awt.Color;
import java.util.List;

/**
 * Representa un hoyo en el tablero del Demonio de Maxwell.
 * Los hoyos pueden capturar partículas que caen en ellos.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class Hole extends Square {
    private int row;
    private int col;
    private static final Color HOLE_COLOR = Color.DARK_GRAY;

    /**
     * Constructor que crea un hoyo en la posición especificada.
     *
     * @param row Fila donde se ubicará el hoyo
     * @param col Columna donde se ubicará el hoyo
     */
    public Hole(int row, int col) {
        super(HOLE_COLOR);
        this.row = row;
        this.col = col;
    }

    /**
     * Obtiene la fila donde se encuentra el hoyo.
     *
     * @return Número de fila
     */
    public int getRow() {
        return row;
    }

    /**
     * Obtiene la columna donde se encuentra el hoyo.
     *
     * @return Número de columna
     */
    public int getCol() {
        return col;
    }

    /**
     * Elimina las partículas que coincidan con la posición de este hoyo.
     * 
     * @param particles Lista de partículas a verificar
     */
    public void consumeParticle(List<Particle> particles) {
        particles.removeIf(particle -> particle.getRow() == row && particle.getCol() == col);
    }
}