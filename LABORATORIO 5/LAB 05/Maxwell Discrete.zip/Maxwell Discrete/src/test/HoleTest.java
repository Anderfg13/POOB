package test;

import domain.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class HoleTest {

    @Test
    public void getRow_shouldReturnCorrectRow() {
        Hole hole = new Hole(5, 10);
        assertEquals(5, hole.getRow());
    }

    @Test
    public void getCol_shouldReturnCorrectCol() {
        Hole hole = new Hole(5, 10);
        assertEquals(10, hole.getCol());
    }
}
