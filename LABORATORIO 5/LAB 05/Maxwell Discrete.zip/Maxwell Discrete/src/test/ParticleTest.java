package test;

import domain.*;
import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.Color;

public class ParticleTest {

    @Test
    public void getRow_shouldReturnCorrectRow() {
        Particle particle = new Particle(Color.RED, 3, 7);
        assertEquals(3, particle.getRow());
    }

    @Test
    public void getCol_shouldReturnCorrectCol() {
        Particle particle = new Particle(Color.RED, 3, 7);
        assertEquals(7, particle.getCol());
    }

    @Test
    public void getColor_shouldReturnCorrectColor() {
        Particle particle = new Particle(Color.BLUE, 1, 2);
        assertEquals(Color.BLUE, particle.getColor());
    }

    @Test
    public void setRow_shouldChangeRow() {
        Particle particle = new Particle(Color.RED, 3, 7);
        particle.setRow(5);
        assertEquals(5, particle.getRow());
    }

    @Test
    public void setCol_shouldChangeCol() {
        Particle particle = new Particle(Color.RED, 3, 7);
        particle.setCol(9);
        assertEquals(9, particle.getCol());
    }

    @Test
    public void setColor_shouldChangeColor() {
        Particle particle = new Particle(Color.RED, 3, 7);
        particle.setColor(Color.GREEN);
        assertEquals(Color.GREEN, particle.getColor());
    }
}
