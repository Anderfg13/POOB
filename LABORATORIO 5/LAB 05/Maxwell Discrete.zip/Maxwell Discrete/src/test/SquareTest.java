package test;

import domain.Square;
import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.Color;



public class SquareTest {
    @Test
    public void getColor_shouldReturnCorrectColor() {
        Square square = new Square(Color.GREEN);
        assertEquals(Color.GREEN, square.getColor());
    }

    @Test
    public void setColor_shouldChangeTheColor() {
        Square square = new Square(Color.BLUE);
        square.setColor(Color.RED);
        assertEquals(Color.RED, square.getColor());
    }

    @Test
    public void constructor_shouldInitializeColorCorrectly() {
        Square square = new Square(Color.BLACK);
        assertEquals(Color.BLACK, square.getColor());
    }
}