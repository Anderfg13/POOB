package test; 

import domain.*;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class DMaxwellTest {

    private DMaxwell maxwell;
    private List<Particle> particles;
    private List<Hole> holes;
    private int rows;
    private int cols;

    @Before
    public void setUp() {
        rows = 10;
        cols = 20;
        particles = new ArrayList<>();
        holes = new ArrayList<>();
        maxwell = new DMaxwell(rows, cols, particles, holes);
    }

    @Test
    public void shouldMoveParticleUp() {
        Particle particle = new Particle(Color.RED, 5, 5);
        particles.add(particle);
        maxwell.moveParticle(particle, DMaxwell.UP);
        assertEquals(4, particle.getRow());
        assertEquals(5, particle.getCol());
    }

    @Test
    public void shouldMoveParticleDown() {
        Particle particle = new Particle(Color.RED, 5, 5);
        particles.add(particle);
        maxwell.moveParticle(particle, DMaxwell.DOWN);
        assertEquals(6, particle.getRow());
        assertEquals(5, particle.getCol());
    }

    @Test
    public void shouldMoveParticleLeft() {
        Particle particle = new Particle(Color.RED, 5, 5);
        particles.add(particle);
        maxwell.moveParticle(particle, DMaxwell.LEFT);
        assertEquals(5, particle.getRow());
        assertEquals(4, particle.getCol());
    }

    @Test
    public void shouldMoveParticleRight() {
        Particle particle = new Particle(Color.RED, 5, 5);
        particles.add(particle);
        maxwell.moveParticle(particle, DMaxwell.RIGHT);
        assertEquals(5, particle.getRow());
        assertEquals(6, particle.getCol());
    }

    @Test
    public void shouldNotMoveParticleIntoWall() {
        Particle particle = new Particle(Color.RED, 0, 0);
        particles.add(particle);
        maxwell.moveParticle(particle, DMaxwell.UP);
        assertEquals(0, particle.getRow());
        assertEquals(0, particle.getCol());
    }

    
    @Test
    public void shouldReturnCorrectInformation() {
        particles.add(new Particle(Color.RED, 5, 2));
        particles.add(new Particle(Color.BLUE, 5, 18));
        particles.add(new Particle(Color.RED, 5, 15));
        particles.add(new Particle(Color.BLUE, 5, 3));
        double percentage = maxwell.infoContainer();
        assertEquals(50.0, percentage, 0.01);
    }



    @Test
    public void shouldNotMoveParticleIfOccupied() {
        Particle particle1 = new Particle(Color.RED, 5, 5);
        Particle particle2 = new Particle(Color.BLUE, 4, 5);
        particles.add(particle1);
        particles.add(particle2);
        maxwell.moveParticle(particle1, DMaxwell.UP);
        assertEquals(5, particle1.getRow());
        assertEquals(5, particle1.getCol());
    }
}
