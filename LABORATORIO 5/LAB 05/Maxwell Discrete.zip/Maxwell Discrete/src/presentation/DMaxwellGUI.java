package presentation;

import domain.Hole;
import domain.Particle;
import domain.Square;
import domain.DMaxwell; // Import DMaxwell from the domain package

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

/**
 * Interfaz gráfica para la simulación del Demonio de Maxwell discreto.
 * Permite visualizar y controlar el movimiento de partículas en un tablero con hoyos.
 * 
 * @author Anderson Fabian Garcia Nieto
 * @author Christian Alfonso Romero Martinez
 * @version 1.0
 * @since 2025-04-18
 */
public class DMaxwellGUI extends JFrame {

    private static final String WINDOW_TITLE = "Maxwell Discreto";
    private static final String CONFIRMATION_MESSAGE = "¿Estás seguro de que deseas salir?";
    private static final String COLOR_CHOOSER_TITLE = "Seleccione un color";
    private static final String PARTICLE_COLOR_SELECTION = "¿De qué color quieres cambiar las partículas?";
    private static final String RED_PARTICLES = "Rojas";
    private static final String BLUE_PARTICLES = "Azules";

    private  Color DEFAULT_RED_COLOR = new Color(255, 0, 0);
    private  Color DEFAULT_BLUE_COLOR = new Color(0, 0, 255);
    private  int DEFAULT_ROWS = 11;
    private  int DEFAULT_COLS = 40;
    private  int DEFAULT_HOLES = 6;
    private  int DEFAULT_RED_PARTICLES = 10;
    private  int DEFAULT_BLUE_PARTICLES = 10;

    private JPanel mainPanel;
    private JPanel boardPanel;
    private int rows = DEFAULT_ROWS;
    private int cols = DEFAULT_COLS;
    private Color wallColor = Color.BLACK;
    private Color emptyColor = Color.WHITE;
    private Color gridColor = new Color(220, 220, 220);
    private List<Particle> particles = new ArrayList<>();
    private List<Hole> holes = new ArrayList<>();
    private Random random = new Random();
    private int numHoles = DEFAULT_HOLES;
    private int numRedParticles = DEFAULT_RED_PARTICLES;
    private int numBlueParticles = DEFAULT_BLUE_PARTICLES;

    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenu configMenu;
    private JMenuItem newMenuItem, openMenuItem, saveMenuItem, exitMenuItem, changeColorMenuItem;
    private JMenu infoMenu;
    private JMenuItem showInfoMenuItem;
    private JMenuItem modifyBoardMenuItem;
    private JMenuItem resetMenuItem;

    private DMaxwell maxwell; // Instance of the domain class
    private boolean running = false; // Flag to control particle movement
    private JPanel southPanel;
    private JButton[] arrowButtons;
    private JButton startButton;

    /**
     * Constructor por defecto que inicializa la interfaz con valores predeterminados.
     */
    public DMaxwellGUI() {
        super(WINDOW_TITLE);
        prepareElements();
    }

    /**
     * Constructor que permite configurar dimensiones y cantidad de elementos.
     *
     * @param rows Número de filas del tablero
     * @param cols Número de columnas del tablero
     * @param numRedParticles Cantidad de partículas rojas iniciales
     * @param numBlueParticles Cantidad de partículas azules iniciales
     * @param numHoles Cantidad de hoyos iniciales
     */
    public DMaxwellGUI(int rows, int cols, int numRedParticles, int numBlueParticles, int numHoles) {
        super(WINDOW_TITLE);
        this.rows = rows;
        this.cols = cols;
        this.numRedParticles = numRedParticles;
        this.numBlueParticles = numBlueParticles;
        this.numHoles = numHoles;
        prepareElements();
    }

    /**
     * Prepara todos los elementos de la interfaz gráfica.
     */
    private void prepareElements() {
        maxwell = new DMaxwell(rows, cols, particles, holes);
        
        setupFrame();
        setupMainPanel();
        prepareElementsMenu();
        createMenu();
        createButtonsAndArrows();
        prepareActions();
        prepareActionsMenu();
        setVisible(true);
    }

    /**
     * Configura las propiedades básicas de la ventana principal.
     */
    private void setupFrame() {
        setTitle(WINDOW_TITLE);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApplication();
            }
        });

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                refresh();
            }
        });

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        int windowWidth = screenWidth / 2;
        int windowHeight = screenHeight / 2;

        setSize(windowWidth, windowHeight);
        setLocationRelativeTo(null);
    }

    /**
     * Configura el panel principal de la interfaz.
     */
    private void setupMainPanel() {
        mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);
    }

    /**
     * Prepara los elementos del menú y el tablero de juego.
     */
    private void prepareElementsMenu() {
        boardPanel = new JPanel(new GridLayout(rows, cols));
        mainPanel.add(boardPanel, BorderLayout.CENTER);

        createHoles();
        createParticles();
        refresh();
    }

    /**
     * Crea los hoyos en posiciones aleatorias del tablero.
     */
    private void createHoles() {
        for (int i = 0; i < numHoles; i++) {
            addHole();
        }
    }

    /**
     * Crea las partículas en posiciones aleatorias del tablero.
     */
    private void createParticles() {
        for (int i = 0; i < numRedParticles; i++) {
            addParticle(DEFAULT_RED_COLOR);
        }
        for (int i = 0; i < numBlueParticles; i++) {
            addParticle(DEFAULT_BLUE_COLOR);
        }
    }

    /**
     * Crea la barra de menú y sus opciones.
     */
    private void createMenu() {
        menuBar = new JMenuBar();
        fileMenu = new JMenu("Archivo");
        configMenu = new JMenu("Configuración");
        infoMenu = new JMenu("Información");

        newMenuItem = new JMenuItem("Nuevo");
        openMenuItem = new JMenuItem("Abrir");
        saveMenuItem = new JMenuItem("Salvar");
        exitMenuItem = new JMenuItem("Salir");
        resetMenuItem = new JMenuItem("Reiniciar");
        changeColorMenuItem = new JMenuItem("Cambiar Color Partículas");
        showInfoMenuItem = new JMenuItem("Mostrar Información");
        modifyBoardMenuItem = new JMenuItem("Modificar Tablero");

        fileMenu.add(newMenuItem);
        fileMenu.add(resetMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(openMenuItem);
        fileMenu.add(saveMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(exitMenuItem);

        configMenu.add(changeColorMenuItem);
        configMenu.add(modifyBoardMenuItem);
        infoMenu.add(showInfoMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(configMenu);
        menuBar.add(infoMenu);
        setJMenuBar(menuBar);
    }

    /**
     * Crea los botones de control y las flechas de dirección.
     */
    private void createButtonsAndArrows() {
        southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setPreferredSize(new Dimension(150, 0));

        startButton = new JButton("Start");
        startButton.setFont(new Font("Arial", Font.BOLD, 16));
        startButton.setPreferredSize(new Dimension(100, 40));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        leftPanel.add(startButton, gbc);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JLabel centerText = new JLabel("Maxwell 'Demon", SwingConstants.CENTER);
        centerText.setFont(new Font("Serif", Font.BOLD, 32));
        centerPanel.add(centerText, BorderLayout.CENTER);

        JPanel arrowPanel = new JPanel(new GridLayout(3, 3, 2, 2));
        arrowButtons = new JButton[4];

        for (int i = 0; i < 9; i++) {
            JButton button = new JButton();
            button.setPreferredSize(new Dimension(40, 40));
            button.setFont(new Font("Arial", Font.BOLD, 16));
            button.setMargin(new Insets(0, 0, 0, 0));

            if (i == 1) {
                button.setText("↑");
                arrowButtons[0] = button;
            } else if (i == 3) {
                button.setText("←");
                arrowButtons[1] = button;
            } else if (i == 5) {
                button.setText("→");
                arrowButtons[2] = button;
            } else if (i == 7) {
                button.setText("↓");
                arrowButtons[3] = button;
            } else {
                button.setEnabled(false);
                button.setVisible(false);
            }

            if (button.isEnabled()) {
                button.setBackground(new Color(240, 240, 240));
                button.setFocusPainted(false);
            }

            arrowPanel.add(button);
        }

        JPanel arrowContainer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        arrowContainer.add(arrowPanel);

        southPanel.add(leftPanel, BorderLayout.WEST);
        southPanel.add(centerPanel, BorderLayout.CENTER);
        southPanel.add(arrowContainer, BorderLayout.EAST);

        mainPanel.add(southPanel, BorderLayout.SOUTH);

        setArrowButtonsEnabled(false);
    }

    /**
     * Configura los listeners para los botones de control.
     */
    private void prepareActions() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exitApplication();
            }
        });

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                refresh();
            }
        });

        startButton.addActionListener(e -> toggleStart());
        arrowButtons[0].addActionListener(e -> moveAllParticles(DMaxwell.UP));
        arrowButtons[1].addActionListener(e -> moveAllParticles(DMaxwell.LEFT));
        arrowButtons[2].addActionListener(e -> moveAllParticles(DMaxwell.RIGHT));
        arrowButtons[3].addActionListener(e -> moveAllParticles(DMaxwell.DOWN));
    }

    /**
     * Configura los listeners para las opciones del menú.
     */
    private void prepareActionsMenu() {
        newMenuItem.addActionListener(e -> resetBoard());
        resetMenuItem.addActionListener(e -> resetGame());
        exitMenuItem.addActionListener(e -> exitApplication());
        changeColorMenuItem.addActionListener(e -> changeParticleColor());
        showInfoMenuItem.addActionListener(e -> showInformation());
        modifyBoardMenuItem.addActionListener(e -> modifyBoardConfiguration());

        openMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                int resultado = chooser.showOpenDialog(DMaxwellGUI.this);

                if (resultado == JFileChooser.APPROVE_OPTION) {
                    File archivo = chooser.getSelectedFile();
                    JOptionPane.showMessageDialog(
                            DMaxwellGUI.this,
                            "Función 'Abrir' en construcción.\nArchivo seleccionado: " + archivo.getName(),
                            "Aviso",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        });

        saveMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                int resultado = chooser.showSaveDialog(DMaxwellGUI.this);

                if (resultado == JFileChooser.APPROVE_OPTION) {
                    File archivo = chooser.getSelectedFile();
                    JOptionPane.showMessageDialog(
                            DMaxwellGUI.this,
                            "Función 'Salvar' en construcción.\nArchivo seleccionado: " + archivo.getName(),
                            "Aviso",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        });
    }

    /**
     * Alterna el estado de inicio/detenido de la simulación.
     */
    private void toggleStart() {
        running = !running;
        setArrowButtonsEnabled(running);
        startButton.setText(running ? "Stop" : "Start");
    }

    /**
     * Mueve todas las partículas en la dirección especificada.
     *
     * @param direction Dirección del movimiento (UP, DOWN, LEFT, RIGHT)
     */
    private void moveAllParticles(int direction) {
        if (!running) {
            return;
        }
        
        List<Particle> particlesToRemove = new ArrayList<>();
        
        for (Particle particle : new ArrayList<>(particles)) {
            int newRow = particle.getRow();
            int newCol = particle.getCol();

            switch (direction) {
                case DMaxwell.UP:
                    newRow--;
                    break;
                case DMaxwell.DOWN:
                    newRow++;
                    break;
                case DMaxwell.LEFT:
                    newCol--;
                    break;
                case DMaxwell.RIGHT:
                    newCol++;
                    break;
            }

            if (maxwell.isValidMove(newRow, newCol)) {
                particle.move(newRow, newCol);
                
                if (isHole(newRow, newCol)) {
                    particlesToRemove.add(particle);
                }
            }
        }
        
        particles.removeAll(particlesToRemove);
        refresh();
    }

    /**
     * Reinicia el tablero eliminando todas las partículas y hoyos.
     */
    private void resetBoard() {
        particles.clear();
        holes.clear();
        prepareElementsMenu();
    }

    /**
     * Reinicia completamente el juego con la configuración actual.
     */
    private void resetGame() {
        running = false;
        setArrowButtonsEnabled(false);
        startButton.setText("Start");

        particles.clear();
        holes.clear();
        
        maxwell = new DMaxwell(rows, cols, particles, holes);
        
        createHoles();
        createParticles();
        
        maxwell = new DMaxwell(rows, cols, particles, holes);
        
        refresh();
        revalidate();
        repaint();
    }

    /**
     * Añade un hoyo en una posición aleatoria del tablero.
     */
    private void addHole() {
        int row, col;
        do {
            row = random.nextInt(rows);
            col = random.nextInt(cols);
        } while (isWall(row, col) || isOccupied(row, col));

        Hole hole = new Hole(row, col);
        holes.add(hole);
    }

    /**
     * Añade una partícula en una posición aleatoria del tablero.
     *
     * @param color Color de la partícula a añadir
     */
    private void addParticle(Color color) {
        int row, col;
        do {
            row = random.nextInt(rows);
            col = random.nextInt(cols);
        } while (isWall(row, col) || isOccupied(row, col));

        Particle particle = new Particle(color, row, col);
        particles.add(particle);
    }

    /**
     * Verifica si una posición dada corresponde a una pared.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición es una pared, false en caso contrario
     */
    private boolean isWall(int row, int col) {
        if (col == 0 || col == cols - 1 || row == 0 || row == rows - 1) {
            return true;
        }

        int middleCol = cols / 2;
        int middleRow = rows / 2;
        if (col == middleCol && row != middleRow) {
            return true;
        }

        return false;
    }

    /**
     * Verifica si una posición dada está ocupada por una partícula.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición está ocupada, false en caso contrario
     */
    private boolean isOccupied(int row, int col) {
        for (Particle particle : particles) {
            if (particle.getRow() == row && particle.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    /**
     * Actualiza la visualización del tablero.
     */
    private void refresh() {
        boardPanel.removeAll();
        boardPanel.setLayout(new GridLayout(rows, cols));

        Dimension boardSize = boardPanel.getSize();
        int cellWidth = Math.max(boardSize.width / cols, 10);
        int cellHeight = Math.max(boardSize.height / rows, 10);
        Dimension cellSize = new Dimension(cellWidth, cellHeight);

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                Square cell;

                if (isWall(row, col)) {
                    cell = new Square(wallColor);
                } else if (isHole(row, col)) {
                    cell = new Hole(row, col);
                } else if (isParticle(row, col)) {
                    cell = getParticleAt(row, col);
                } else {
                    cell = new Square(emptyColor);
                }

                cell.setBorder(new LineBorder(gridColor));
                cell.setPreferredSize(cellSize);
                boardPanel.add(cell);
            }
        }

        boardPanel.revalidate();
        boardPanel.repaint();
    }

    /**
     * Obtiene la partícula en una posición específica del tablero.
     *
     * @param row Fila de la partícula
     * @param col Columna de la partícula
     * @return La partícula en la posición especificada, o null si no hay ninguna
     */
    private Particle getParticleAt(int row, int col) {
        for (Particle particle : particles) {
            if (particle.getRow() == row && particle.getCol() == col) {
                return particle;
            }
        }
        return null;
    }

    /**
     * Verifica si una posición dada contiene un hoyo.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición contiene un hoyo, false en caso contrario
     */
    private boolean isHole(int row, int col) {
        for (Hole hole : holes) {
            if (hole.getRow() == row && hole.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    /**
     * Verifica si una posición dada contiene una partícula.
     *
     * @param row Fila a verificar
     * @param col Columna a verificar
     * @return true si la posición contiene una partícula, false en caso contrario
     */
    private boolean isParticle(int row, int col) {
        for (Particle particle : particles) {
            if (particle.getRow() == row && particle.getCol() == col) {
                return true;
            }
        }
        return false;
    }

    /**
     * Muestra un diálogo de confirmación antes de cerrar la aplicación.
     */
    private void exitApplication() {
        int option = JOptionPane.showConfirmDialog(
                this,
                CONFIRMATION_MESSAGE,
                "Confirmación",
                JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    /**
     * Permite cambiar el color de las partículas (rojas o azules).
     */
    private void changeParticleColor() {
        String[] options = {RED_PARTICLES, BLUE_PARTICLES};
        int choice = JOptionPane.showOptionDialog(
                this,
                PARTICLE_COLOR_SELECTION,
                "Cambiar Color Partículas",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        Color newColor = JColorChooser.showDialog(this, COLOR_CHOOSER_TITLE, Color.WHITE);

        if (newColor != null) {
            if (choice == 0) {
                for (Particle particle : particles) {
                    if (particle.getColor().equals(DEFAULT_RED_COLOR)) {
                        particle.setColor(newColor);
                    }
                }
            } else if (choice == 1) {
                for (Particle particle : particles) {
                    if (particle.getColor().equals(DEFAULT_BLUE_COLOR)) {
                        particle.setColor(newColor);
                    }
                }
            }
            refresh();
        }
    }

    /**
     * Habilita o deshabilita los botones de dirección.
     *
     * @param enabled true para habilitar los botones, false para deshabilitarlos
     */
    private void setArrowButtonsEnabled(boolean enabled) {
        for (JButton button : arrowButtons) {
            if (button != null) {
                button.setEnabled(enabled);
            }
        }
    }

    /**
     * Muestra información estadística sobre la simulación.
     */
    private void showInformation() {
        maxwell = new DMaxwell(rows, cols, particles, holes);
        
        double percentage = maxwell.infoContainer();
        double lostPercentage = maxwell.getLostInHolesPercentage();
        String message = String.format("Porcentaje de partículas bien ubicadas: %.2f%%\n" +
                                     "Porcentaje de partículas atrapadas en hoyos: %.2f%%",
                                     percentage, lostPercentage);
        JOptionPane.showMessageDialog(this, message, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Permite modificar la configuración del tablero a través de un diálogo.
     */
    private void modifyBoardConfiguration() {
        JPanel panel = new JPanel(new GridLayout(0, 1));
        JTextField rowsField = new JTextField(String.valueOf(rows), 5);
        JTextField colsField = new JTextField(String.valueOf(cols), 5);
        JTextField redParticlesField = new JTextField(String.valueOf(numRedParticles), 5);
        JTextField blueParticlesField = new JTextField(String.valueOf(numBlueParticles), 5);
        JTextField holesField = new JTextField(String.valueOf(numHoles), 5);

        panel.add(new JLabel("Filas:"));
        panel.add(rowsField);
        panel.add(new JLabel("Columnas:"));
        panel.add(colsField);
        panel.add(new JLabel("Partículas Rojas:"));
        panel.add(redParticlesField);
        panel.add(new JLabel("Partículas Azules:"));
        panel.add(blueParticlesField);
        panel.add(new JLabel("Número de Hoyos:"));
        panel.add(holesField);

        int result = JOptionPane.showConfirmDialog(null, panel,
                "Configuración del Tablero", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                int newRows = Integer.parseInt(rowsField.getText());
                int newCols = Integer.parseInt(colsField.getText());
                int newRedParticles = Integer.parseInt(redParticlesField.getText());
                int newBlueParticles = Integer.parseInt(blueParticlesField.getText());
                int newHoles = Integer.parseInt(holesField.getText());

                if (newRows > 0 && newCols > 0 && newRedParticles >= 0 && newBlueParticles >= 0 && newHoles >= 0) {
                    this.rows = newRows+2;
                    this.cols = (newCols*2)+3;
                    this.numRedParticles = newRedParticles;
                    this.numBlueParticles = newBlueParticles;
                    this.numHoles = newHoles;
                    
                    resetGame();
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Por favor, ingrese valores válidos mayores que cero.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this,
                        "Por favor, ingrese números enteros válidos.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Método principal que inicia la aplicación.
     *
     * @param args Argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(DMaxwellGUI::new);
    }
}