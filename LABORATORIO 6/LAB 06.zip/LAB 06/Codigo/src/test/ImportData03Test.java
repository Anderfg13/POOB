package test;

import domain.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

/**
 * Clase de pruebas unitarias para el método importData03 de la clase City.
 * Estas pruebas están enfocadas en verificar la importación y exportación de clases dinámicas que implementan la interfaz Item.
 */
public class ImportData03Test {

    private City city;

    @BeforeEach
    public void setUp() {
        city = new City();
    }

    @AfterEach
    public void tearDown() {
        city = null;
    }

    /**
     * Prueba que verifica la importación de un archivo válido con clases existentes.
     */
    @Test
    public void shouldImportValidFileWithExistingClasses() {
        File file = new File("validImport03.txt");

        // Crear un archivo válido con clases existentes
        assertDoesNotThrow(() -> {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Person 10 10\n");
                writer.write("Walker 15 15\n");
                writer.write("TrafficLight 5 5\n");
            }
        });

        // Importar el archivo
        assertDoesNotThrow(() -> city.importData03(file));

        // Verificar que los ítems se hayan importado correctamente
        assertNotNull(city.getItem(10, 10), "El ítem en (10, 10) no fue importado correctamente.");
        assertNotNull(city.getItem(15, 15), "El ítem en (15, 15) no fue importado correctamente.");
        assertNotNull(city.getItem(5, 5), "El ítem en (5, 5) no fue importado correctamente.");

        file.delete(); // Limpieza después de la prueba
    }


    /**
     * Prueba que verifica que se lance una excepción al importar una clase inexistente.
     */
    @Test
    public void shouldThrowExceptionForNonExistentClass() {
        File file = new File("nonExistentClassImport03.txt");

        // Crear un archivo con una clase inexistente
        assertDoesNotThrow(() -> {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("NonExistentClass 10 10\n");
            }
        });

        // Intentar importar el archivo
        Exception exception = assertThrows(CityException.class, () -> city.importData03(file));
        assertTrue(exception.getMessage().contains("Clase no encontrada"), "El mensaje de error no es el esperado.");

        file.delete(); // Limpieza después de la prueba
    }
}