package test;

import domain.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

/**
 * Clase de pruebas unitarias para el método exportData03 de la clase City.
 * Estas pruebas están enfocadas en verificar la exportación de clases dinámicas que implementan la interfaz Item.
 */
public class ExportData03Test {

    private City city;

    @BeforeEach
    public void setUp() {
        city = new City();
    }

    @AfterEach
    public void tearDown() {
        city = null;
    }

    /**
     * Prueba que verifica la exportación de un archivo válido con clases existentes.
     */
    @Test
    public void shouldExportValidFileWithExistingClasses() {
        File file = new File("validExport03.txt");

        // Exportar la ciudad a un archivo válido
        assertDoesNotThrow(() -> city.exportData03(file));

        // Verificar que el archivo fue creado
        assertTrue(file.exists(), "El archivo no fue creado correctamente.");

        // Verificar el contenido del archivo
        assertDoesNotThrow(() -> {
            List<String> lines = Files.readAllLines(file.toPath());
            assertFalse(lines.isEmpty(), "El archivo exportado no debe estar vacío.");
            assertTrue(lines.stream().anyMatch(line -> line.contains("Person")), "El archivo no contiene datos de Person.");
            assertTrue(lines.stream().anyMatch(line -> line.contains("Walker")), "El archivo no contiene datos de Walker.");
            assertTrue(lines.stream().anyMatch(line -> line.contains("TrafficLight")), "El archivo no contiene datos de TrafficLight.");
        });

        file.delete(); // Limpieza después de la prueba
    }

    /**
     * Prueba que verifica la exportación de una clase futura.
     */
    @Test
    public void shouldExportFutureClass() {
        File file = new File("futureClassExport03.txt");

        // Registrar dinámicamente la clase FutureClass
        class FutureClass implements Item {
            private final City city;
            private final int row;
            private final int column;

            public FutureClass(City city, int row, int column) {
                this.city = city;
                this.row = row;
                this.column = column;
            }

            @Override
            public void decide() {
                // Lógica específica para FutureClass
            }
        }

        // Agregar un ítem de la clase futura a la ciudad
        FutureClass futureItem = new FutureClass(city, 8, 8);
        city.setItem(8, 8, futureItem);

        // Exportar la ciudad a un archivo
        assertDoesNotThrow(() -> city.exportData03(file));

        // Verificar que el archivo exportado contiene la clase futura
        assertDoesNotThrow(() -> {
            List<String> lines = Files.readAllLines(file.toPath());
            assertTrue(lines.contains("FutureClass 8 8"), "El archivo exportado no contiene la clase FutureClass.");
        });

        file.delete(); // Limpieza después de la prueba
    }

    /**
     * Prueba que verifica que se lance una excepción al exportar a un archivo nulo.
     */
    @Test
    public void shouldThrowExceptionForNullFile() {
        Exception exception = assertThrows(CityException.class, () -> city.exportData03(null));
        assertEquals("El archivo no puede ser nulo.", exception.getMessage());
    }

    /**
     * Prueba que verifica que se lance una excepción al exportar a una ruta inválida.
     */
    @Test
    public void shouldThrowExceptionForInvalidPath() {
        File file = new File("/invalidPath/export03.txt");

        Exception exception = assertThrows(CityException.class, () -> city.exportData03(file));
        assertTrue(exception.getMessage().contains("Error al exportar la ciudad"), "El mensaje de error no es el esperado.");
    }

    /**
     * Prueba que verifica la exportación de una ciudad vacía.
     */
    @Test
    public void shouldExportEmptyCity() {
        File file = new File("emptyCityExport03.txt");

        // Crear una ciudad vacía
        city = new City();
        for (int r = 0; r < city.getSize(); r++) {
            for (int c = 0; c < city.getSize(); c++) {
                city.setItem(r, c, null);
            }
        }

        // Exportar la ciudad vacía
        assertDoesNotThrow(() -> city.exportData03(file));

        // Verificar que el archivo exportado esté vacío
        assertDoesNotThrow(() -> {
            List<String> lines = Files.readAllLines(file.toPath());
            assertTrue(lines.isEmpty(), "El archivo exportado debe estar vacío.");
        });

        file.delete(); // Limpieza después de la prueba
    }
}