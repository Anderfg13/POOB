package domain;

import java.awt.Color;

public class Runner extends Person {
    private static final long serialVersionUID = 1L; // Versión para la serialización

    
    public Runner(City city, int row, int column) {
        super(city, row, column);
        this.color = Color.red;
        this.state = Agent.INDIFFERENT;
    }
    
}
